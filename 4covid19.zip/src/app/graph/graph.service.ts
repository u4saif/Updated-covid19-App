
import {Injectable} from "@angular/core";
import {HttpClient,HttpHeaders} from "@angular/common/http";
import 'rxjs/add/operator/map';

@Injectable()
export class GraphUpdateAPI{
  constructor(private _http: HttpClient){}
   getData(){
    const api='https://api.covid19india.org/data.json';
    return this._http.get(api).map( res=> res);
    // let name=[];
    // let total=[];
    // let death=[];
    // let confirmed=[];
    // async function geIt(){
    // const data= await fetch(api);
    // const value=await data.json();
    // const state=value.statewise;
    // state.slice(1).forEach(a=> { name.push( a.state)});
    // state.slice(1).forEach(a=> { total.push( a.active)});
    // state.slice(1).forEach(d=> death.push(d.deaths));
    // state.slice(1).forEach(d=> confirmed.push(d.confirmed));
    
    // console.log(name);
    // return name;}

  
  

  
}
}