import { Component,OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import {Chart} from 'chart.js';

@Component({
  selector:'graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.css']
})

export class Graph  {
 
  constructor(private http:HttpClient){}

   ngOnInit(){
 

    var ctx = document.getElementById('myChart');
    var ctx2 = document.getElementById('myChart2');
    var ctx3 = document.getElementById('myChart3');
    var ctx4 = document.getElementById('myChart4');
    var ctx5 = document.getElementById('myChart5');
    let name=[];
    let name2=[];
    let statenamelabel=[];
    let  shortname=[];
    let  shortname2=[];
    let active=[];
    let death=[];
    let death2=[];
    let reported=[];
    let recovered=[];
    const cases_time_series=[];
    const cases_time_value=[];
    const cases_time_label=[];
    const totalconfirmed=[];
    let url="https://api.covid19india.org/data.json";
    let obs= this.http.get(url);
    obs.subscribe((response)=>{

      const state=Object.values(response);
      state.forEach(a=> { name.push(a)});

      name[1].forEach(b=>name2.push(b));
      name[0].forEach(b=>cases_time_series.push(b));
   
   
      name2.slice(1,28).forEach(c=> statenamelabel.push(c.state));
      name2.slice(1,14).forEach(c=> shortname.push(c.state));
      name2.slice(1,7).forEach(c=> shortname2.push(c.state));
      name2.slice(1,28).forEach(c=> reported.push(c.confirmed));
      name2.slice(1,28).forEach(c=> active.push(c.active));
      name2.slice(1,14).forEach(c=> death.push(c.deaths));
      name2.slice(1,7).forEach(c=> death2.push(c.deaths));
      name2.slice(1,7).forEach(c=> recovered.push(c.recovered))
      cases_time_series.forEach(c=>cases_time_value.push(c.dailyconfirmed));
      cases_time_series.forEach(c=> cases_time_label.push(c.date));
      cases_time_series.forEach(c=> totalconfirmed.push(c.totalconfirmed));
    
//----------------------------

  var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: statenamelabel,
        datasets: [
        {
            label: '# Total Reported',
            data: reported,
            backgroundColor:'rgba(180, 9, 131,.2)',
            borderColor: 'rgba(180, 9, 131,1)',
            borderWidth: 1
        },{
            label: '# Active Cases',
            data: active,
            backgroundColor: 'rgb(42,0,86,.85)',
            borderColor:  'rgba(42,0,86,1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    
                }
            }]
        }
    }
});
//------------------------------------------------
var myChart = new Chart(ctx5, {
    type: 'radar',
    data: {
        labels: shortname2,
        datasets: [{
            label: '#Number of Recovered',
            data: recovered,
            backgroundColor: 'rgb(8,144,0, 0.5)',
            borderColor:'rgba(0, 0, 0, .7)',
            borderWidth: 1
        },{
            label: '#Number of Deaths',
            data: death2,
            backgroundColor: 'rgb(244,0,0, .9)',
            borderColor:'rgba(0, 0, 0, .7)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            
        }
    }
});
var myRadarChart = new Chart(ctx2, {
    type: 'horizontalBar',
    data: {
    labels: shortname,
    datasets: [{
        label: '#Number of Deaths',
        data: death,
        backgroundColor :'rgba(220, 3, 34,.9)',
        borderColor:'rgba(0, 0, 0, .7)',
        borderWidth: 1
                        
    }],

},options: {
    scales: {
        xAxes: [{
            gridLines: {
                offsetGridLines: false
            }
        }]
    }
}

});
//----------------------------------
var myChart = new Chart(ctx3, {
    type: 'line',
    data: {
        labels: cases_time_label,
        datasets: [
        {
            label: '# Daily confirmed',
            data: cases_time_value,
            backgroundColor:'rgb(253,88,0,.55)',
            borderColor: 'rgba(39, 55, 70, 1)',
            borderWidth: 1
        }]

    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    callback: function (value,index,values){
                        return value;
                    }
                }
            }]
        }
    }});
  //---------------------------------------------------------
  var myChart = new Chart(ctx4, {
    type: 'line',
    data: {
        labels: cases_time_label,
        datasets: [
        {
            label: '# confirmed cases',
            data: totalconfirmed,
            backgroundColor:'rgb(0,80,130,.7)',
            borderColor: 'rgba(33, 47, 61, 1)',
            borderWidth: 4,
            pointStyle:'circle',
            pointRadius:0

        }]

    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    callback: function (value,index,values){
                        return value;
                    }
                }
            }]
        }
    }});


    });
     
    }

   
}

