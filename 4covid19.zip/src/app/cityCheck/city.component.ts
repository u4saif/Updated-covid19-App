import  {Component,OnInit, Input} from '@angular/core';
import  {HttpClient } from '@angular/common/http';
import  {Chart} from 'chart.js';

@Component({
  selector:'city',
  templateUrl:'./city.component.html',
  styleUrls:['./city.component.css'],

  
})

export class City  {
  constructor(private http:HttpClient){}
  cityname=[];
  city;
  cityData=[];
  piechart;
  piechart2;
  piechart3;
  piechart4;
  piechart5;
  updatetime;
  ngOnInit(){

//------------------------chartStart-----------------------------------
   
    this.piechart=new Chart(document.getElementById("mychart"),{
    type: 'pie',
    data: {
        labels: "",
        datasets: [
        {
            label: '# Overall report of your city',
            data: "",
            backgroundColor: ['rgb(255,127,80)', 'rgb( 38, 166, 154)','#C80133'],
            borderColor:  'rgba(255,255,255,.8)',
            borderWidth: 1
        }]
    },
    options: {
     
    }
});
//----------------------------------------------------------
//------------------------chart2Start-----------------------------------
   
    this.piechart2=new Chart(document.getElementById("mychart2"),{
    type: 'doughnut',
    data: {
        labels: "",
        datasets: [
        {
            label: 'your city vs  entire country infection rate',
            data: "",
            backgroundColor: ['rgb(255,127,80)','rgba(0,191,255,.5)'],
            borderColor:  'rgba(255,255,255,1)',
            borderWidth: 1
        }]
    },
    options: {
      title: {
        display: true,
        text: ''
      }
     
    }
});
//--------------------------------------------------------
//------------------------chart3Start-----------------------------------
   
    this.piechart3=new Chart(document.getElementById("mychart3"),{
    type: 'doughnut',
    data: {
        labels: "",
        datasets: [
        {
            label: 'your city vs  entire country infection rate',
            data: "",
            backgroundColor: [ 'rgb( 38, 166, 154)', 'rgba(0,191,255,.5)'],
            borderColor:  'rgba(0,0,0,1)',
            borderWidth: 1
        }]
    },
    options: {
      title: {
        display: true,
        text: ''
      }
     
    }
});
//----------------------------------------------------------
//------------------------chart4Start-----------------------------------
   
    this.piechart4=new Chart(document.getElementById("mychart4"),{
    type: 'doughnut',
    data: {
        labels: "",
        datasets: [
        {
            label: 'your city vs  entire country infection rate',
            data: "",
            backgroundColor: ['#C80133','rgba(0,191,255,.5)'],
            borderColor:  'rgba(255,255,255,0.2)',
            borderWidth: 1
        }]
    },
    options: {
      title: {
        display: true,
        text: ''
      }
     
    }
});
//------------------------chart5Start-----------------------------------
   
    this.piechart5=new Chart(document.getElementById("mychart5"),{
    type: 'polarArea',
    data: {
        labels: "",
        datasets: [
        {
            label: '',
            data: "",
            backgroundColor: ['rgb(255,127,80)','rgba(255,215,0,.83)'],
            borderColor:  'rgba(0,0,0,1)',
            borderWidth: 1
        }]
    },
    options: {
      title: {
        display: false,
        text: ''
      }
     
    }
});
//-----------------------------------------------------------
//------------------------chartEnd-----------------------------------
    let api="https://api.covid19india.org/data.json";
    let obs=this.http.get(api);
    obs.subscribe((response)=> 
      {let nameArr=Object.values(response);
      nameArr[1].forEach(a=> {this.cityname.push(a)});
      this.cityname.forEach(a=> {this.cityData.push(a.state)});
       
      });
    
  }
  onCity(val){
    let active;
    let confirmed;
    let recovered;
    let deaths;
    

    let deltaconfirmed;
    let deltadeaths;
    let deltarecovered;

    let n_active;
    let n_confirmed;
    let n_recovered;
    let n_deaths;

    let n_deltaconfirmed;
    let n_deltadeaths;
    let n_deltarecovered;
 

    let confimred;
     
    let index=this.cityData.indexOf(val);
    n_active=this.cityname[0].active;
    n_confirmed=this.cityname[0].confirmed;
    n_recovered=this.cityname[0].recovered;
    n_deaths=this.cityname[0].deaths;

    n_deltaconfirmed=this.cityname[0].deltaconfirmed;
    n_deltadeaths=this.cityname[0].deltadeaths;
    n_deltarecovered=this.cityname[0].deltarecovered;

    active=this.cityname[index].active;
    confirmed=this.cityname[index].confirmed;
    recovered=this.cityname[index].recovered;
    deaths=this.cityname[index].deaths;
    this.updatetime=this.cityname[index].lastupdatedtime.split(" ")[1];

    deltaconfirmed=this.cityname[index].deltaconfirmed;
    deltadeaths=this.cityname[index].deltadeaths;
    deltarecovered=Number(this.cityname[index].deltarecovered);

     
    this.piechart.data.labels=["Active", "Recovered","Deaths" ]
    this.piechart.data.datasets[0].data=[active,recovered,deaths];

    this.piechart2.data.labels=[val,"country" ]
    this.piechart2.data.datasets[0].data=[active,n_active];
    this.piechart2.options.title.text='Active';
    
    this.piechart3.data.labels=[val,"country" ]
    this.piechart3.data.datasets[0].data=[recovered,n_recovered];
    this.piechart3.options.title.text='Recovered';

    this.piechart4.data.labels=[val,"country" ]
    this.piechart4.data.datasets[0].data=[deaths,n_deaths];
    this.piechart4.options.title.text='Deaths';

    this.piechart5.data.labels=["Active","Reported"]
    this.piechart5.data.datasets[0].data=[active,confirmed];
    this.piechart5.options.title.text='Recovered';
    
    this.piechart.update();
    this.piechart2.update();
    this.piechart3.update();
    this.piechart4.update();
    this.piechart5.update();

  }

}